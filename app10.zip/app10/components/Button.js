import React from 'react';
import { Text, StyleSheet, ActivityIndicator } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { 
  useAnimatedStyle, 
  useSharedValue, 
  withSpring,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import PressableScale from './PressableScale';
import { Colors, FontSizes, BorderRadius, Spacing, FontWeights, Shadows, Typography } from '../constants/theme';

export default function Button({ 
  title, 
  onPress, 
  variant = 'primary',
  size = 'large',
  loading = false,
  disabled = false,
  icon = null,
  style,
  fullWidth = true,
}) {
  const shimmer = useSharedValue(0);

  const getGradientColors = () => {
    if (disabled) return [Colors.backgroundGray, Colors.borderDark];
    switch (variant) {
      case 'primary': return Colors.gradientTwilight;
      case 'accent': return Colors.gradientSunset;
      case 'success': return Colors.gradientSuccess;
      case 'purple': return Colors.gradientPurple;
      case 'blue': return Colors.gradientBlue;
      default: return Colors.gradientTwilight;
    }
  };

  const getTextColor = () => {
    if (variant === 'secondary' || variant === 'outline') return Colors.textPrimary;
    return Colors.textLight;
  };

  const getHeight = () => {
    switch (size) {
      case 'small': return 44;
      case 'medium': return 52;
      case 'large': return 60;
      default: return 60;
    }
  };

  const getFontSize = () => {
    switch (size) {
      case 'small': return FontSizes.sm;
      case 'medium': return FontSizes.md;
      case 'large': return FontSizes.lg;
      default: return FontSizes.lg;
    }
  };

  const handlePress = () => {
    shimmer.value = withSequence(
      withTiming(1, { duration: 150 }),
      withTiming(0, { duration: 150 })
    );
    onPress && onPress();
  };

  if (variant === 'outline' || variant === 'secondary') {
    return (
      <PressableScale
        onPress={handlePress}
        disabled={disabled || loading}
        style={[
          styles.button,
          {
            height: getHeight(),
            backgroundColor: variant === 'secondary' ? Colors.backgroundGray : 'transparent',
            borderWidth: variant === 'outline' ? 2 : 0,
            borderColor: variant === 'outline' ? Colors.primary : 'transparent',
            width: fullWidth ? '100%' : 'auto',
          },
          style,
        ]}
      >
        {loading ? (
          <ActivityIndicator color={getTextColor()} size="small" />
        ) : (
          <>
            {icon}
            <Text style={[styles.text, { color: getTextColor(), fontSize: getFontSize() }]}>
              {title}
            </Text>
          </>
        )}
      </PressableScale>
    );
  }

  return (
    <PressableScale
      onPress={handlePress}
      disabled={disabled || loading}
      style={[
        { width: fullWidth ? '100%' : 'auto' },
        style,
      ]}
    >
      <LinearGradient
        colors={getGradientColors()}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={[
          styles.button,
          styles.gradient,
          {
            height: getHeight(),
          },
          disabled && styles.disabled,
        ]}
      >
        {loading ? (
          <ActivityIndicator color={getTextColor()} size="small" />
        ) : (
          <>
            {icon}
            <Text style={[styles.text, { color: getTextColor(), fontSize: getFontSize() }]}>
              {title}
            </Text>
          </>
        )}
      </LinearGradient>
    </PressableScale>
  );
}

const styles = StyleSheet.create({
  button: {
    borderRadius: BorderRadius.xl,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: Spacing.xxl,
    gap: Spacing.md,
    ...Shadows.medium,
  },
  gradient: {
    shadowColor: Colors.shadow.twilight,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 6,
  },
  text: {
    fontWeight: FontWeights.bold,
    letterSpacing: 0.5,
  },
  disabled: {
    opacity: 0.5,
  },
});
