import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, Dimensions } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  interpolate,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { Colors, Spacing, FontSizes, FontWeights, BorderRadius, Shadows, Motion } from '../constants/theme';
import { useResponsiveLayout } from '../hooks/useResponsiveLayout';

const { width } = Dimensions.get('window');

export default function SmartCarousel({ 
  items = [],
  onItemPress,
  autoPlay = true,
  autoPlayInterval = 4000,
}) {
  const { spacing, isXS } = useResponsiveLayout();
  const [activeIndex, setActiveIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const scrollViewRef = useRef(null);
  
  const ITEM_WIDTH = width - spacing.lg * 2;
  const ITEM_MARGIN = spacing.md;

  useEffect(() => {
    if (!autoPlay || isPaused || items.length <= 1) return;

    const interval = setInterval(() => {
      setActiveIndex((prevIndex) => {
        const nextIndex = (prevIndex + 1) % items.length;
        
        scrollViewRef.current?.scrollTo({
          x: nextIndex * (ITEM_WIDTH + ITEM_MARGIN),
          animated: true,
        });
        
        return nextIndex;
      });
    }, autoPlayInterval);

    return () => clearInterval(interval);
  }, [autoPlay, isPaused, items.length, ITEM_WIDTH, ITEM_MARGIN]);

  const handleScroll = (event) => {
    const scrollPosition = event.nativeEvent.contentOffset.x;
    const index = Math.round(scrollPosition / (ITEM_WIDTH + ITEM_MARGIN));
    setActiveIndex(index);
  };

  const handleScrollBeginDrag = () => {
    setIsPaused(true);
  };

  const handleScrollEndDrag = () => {
    setTimeout(() => setIsPaused(false), 2000);
  };

  if (!items || items.length === 0) return null;

  return (
    <View style={styles.container}>
      <ScrollView
        ref={scrollViewRef}
        horizontal
        pagingEnabled={false}
        showsHorizontalScrollIndicator={false}
        onScroll={handleScroll}
        onScrollBeginDrag={handleScrollBeginDrag}
        onScrollEndDrag={handleScrollEndDrag}
        scrollEventThrottle={16}
        decelerationRate="fast"
        snapToInterval={ITEM_WIDTH + ITEM_MARGIN}
        snapToAlignment="start"
        contentContainerStyle={[styles.scrollContent, { gap: ITEM_MARGIN }]}
      >
        {items.map((item, index) => (
          <CarouselItem
            key={item.id}
            item={item}
            width={ITEM_WIDTH}
            isActive={index === activeIndex}
            onPress={() => onItemPress?.(item)}
          />
        ))}
      </ScrollView>

      <View style={styles.pagination}>
        {items.map((_, index) => (
          <PaginationDot
            key={index}
            isActive={index === activeIndex}
          />
        ))}
      </View>
    </View>
  );
}

function CarouselItem({ item, width, isActive, onPress }) {
  const scale = useSharedValue(0.95);

  useEffect(() => {
    scale.value = withSpring(isActive ? 1 : 0.95, Motion.spring.gentle);
  }, [isActive]);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  return (
    <Animated.View style={[animatedStyle, { width }]}>
      <TouchableOpacity
        style={styles.itemContainer}
        activeOpacity={0.95}
        onPress={onPress}
      >
        <Image
          source={{ uri: item.image }}
          style={styles.itemImage}
          resizeMode="cover"
        />
        
        <LinearGradient
          colors={['transparent', 'rgba(0,0,0,0.7)']}
          style={styles.itemGradient}
        >
          <View style={styles.itemContent}>
            {item.badge && (
              <View style={styles.itemBadge}>
                <Text style={styles.itemBadgeText}>{item.badge}</Text>
              </View>
            )}
            
            <Text style={styles.itemTitle} numberOfLines={2}>
              {item.title}
            </Text>
            
            <Text style={styles.itemSubtitle} numberOfLines={1}>
              {item.subtitle}
            </Text>
          </View>
        </LinearGradient>
      </TouchableOpacity>
    </Animated.View>
  );
}

function PaginationDot({ isActive }) {
  const width = useSharedValue(8);
  const opacity = useSharedValue(0.3);

  useEffect(() => {
    width.value = withSpring(isActive ? 24 : 8, Motion.spring.snappy);
    opacity.value = withSpring(isActive ? 1 : 0.3, Motion.spring.gentle);
  }, [isActive]);

  const animatedStyle = useAnimatedStyle(() => ({
    width: width.value,
    opacity: opacity.value,
  }));

  return (
    <Animated.View style={[styles.paginationDot, animatedStyle]} />
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: Spacing.xl,
  },
  scrollContent: {
    paddingHorizontal: Spacing.lg,
  },
  itemContainer: {
    height: 200,
    borderRadius: BorderRadius.xl,
    overflow: 'hidden',
    ...Shadows.large,
  },
  itemImage: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  itemGradient: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  itemContent: {
    padding: Spacing.lg,
  },
  itemBadge: {
    alignSelf: 'flex-start',
    backgroundColor: Colors.accent,
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.xs,
    borderRadius: BorderRadius.sm,
    marginBottom: Spacing.sm,
  },
  itemBadgeText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
  },
  itemTitle: {
    fontSize: FontSizes.xl,
    fontWeight: FontWeights.bold,
    color: Colors.textLight,
    marginBottom: Spacing.xs,
  },
  itemSubtitle: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.medium,
    color: 'rgba(255, 255, 255, 0.9)',
  },
  pagination: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: Spacing.md,
    gap: Spacing.xs,
  },
  paginationDot: {
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.primary,
  },
});
