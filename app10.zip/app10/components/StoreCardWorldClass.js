import React, { useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withRepeat,
  withSequence,
  withTiming,
  withDelay,
  Easing,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { Colors, Spacing, FontSizes, FontWeights, BorderRadius, Shadows, Motion } from '../constants/theme';
import { useResponsiveLayout } from '../hooks/useResponsiveLayout';

const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);

export default function StoreCardWorldClass({ store, onPress, style }) {
  const { spacing, scaleFont, getContainerWidth } = useResponsiveLayout();
  const scale = useSharedValue(1);
  const shimmerTranslate = useSharedValue(-200);

  useEffect(() => {
    if (store.discount) {
      shimmerTranslate.value = withRepeat(
        withSequence(
          withTiming(200, { duration: 2000, easing: Easing.linear }),
          withTiming(-200, { duration: 0 })
        ),
        -1,
        false
      );
    }
  }, [store.discount]);

  const cardAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const shimmerAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: shimmerTranslate.value }],
  }));

  const handlePressIn = () => {
    scale.value = withSpring(0.98, Motion.spring.snappy);
  };

  const handlePressOut = () => {
    scale.value = withSpring(1, Motion.spring.gentle);
  };

  return (
    <AnimatedTouchable
      style={[styles.container, { marginHorizontal: spacing.lg }, cardAnimatedStyle, style]}
      activeOpacity={0.95}
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
    >
      <View style={styles.imageContainer}>
        <Image
          source={{ uri: store.image }}
          style={styles.image}
          resizeMode="cover"
        />
        
        {store.discount && (
          <View style={styles.discountBadge}>
            <LinearGradient
              colors={Colors.gradientPremiumAmber}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.discountGradient}
            >
              <Animated.View style={[styles.shimmer, shimmerAnimatedStyle]} />
              <Text style={styles.discountText}>{store.discount}</Text>
            </LinearGradient>
          </View>
        )}
        
        <TouchableOpacity style={styles.favoriteButton} activeOpacity={0.7}>
          <Ionicons name="heart-outline" size={20} color={Colors.textLight} />
        </TouchableOpacity>
      </View>

      <View style={[styles.content, { padding: spacing.lg }]}>
        <View style={styles.header}>
          <Text style={[styles.name, { fontSize: scaleFont(FontSizes.lg) }]} numberOfLines={1}>
            {store.name}
          </Text>
          
          <StatusBadge isOpen={store.isOpen} />
        </View>

        {store.tags && store.tags.length > 0 && (
          <View style={styles.tags}>
            {store.tags.slice(0, 3).map((tag, index) => (
              <View key={index} style={styles.tag}>
                <Text style={styles.tagText}>{tag}</Text>
              </View>
            ))}
          </View>
        )}

        <View style={styles.footer}>
          <View style={styles.metrics}>
            <RatingStars rating={store.rating} />
            
            <View style={styles.metricDivider} />
            
            <View style={styles.metric}>
              <Ionicons name="location" size={14} color={Colors.primary} />
              <Text style={styles.metricText}>{store.distance} km</Text>
            </View>
            
            {store.deliveryTime && (
              <>
                <View style={styles.metricDivider} />
                <View style={styles.metric}>
                  <Ionicons name="time-outline" size={14} color={Colors.textSecondary} />
                  <Text style={styles.metricText}>{store.deliveryTime} min</Text>
                </View>
              </>
            )}
          </View>

          {store.deliveryFee !== undefined && (
            <Text style={[
              styles.deliveryFee,
              store.deliveryFee === 0 && styles.deliveryFeeFree
            ]}>
              {store.deliveryFee === 0 ? 'Frete Grátis' : `R$ ${store.deliveryFee.toFixed(2)}`}
            </Text>
          )}
        </View>
      </View>
    </AnimatedTouchable>
  );
}

function StatusBadge({ isOpen }) {
  const pulse = useSharedValue(1);

  useEffect(() => {
    if (isOpen) {
      pulse.value = withRepeat(
        withSequence(
          withSpring(1.2, Motion.spring.gentle),
          withSpring(1, Motion.spring.gentle)
        ),
        -1,
        false
      );
    }
  }, [isOpen]);

  const dotAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulse.value }],
  }));

  return (
    <View style={[
      styles.statusBadge,
      { backgroundColor: isOpen ? Colors.successLight : Colors.errorLight }
    ]}>
      <Animated.View style={[
        styles.statusDot,
        { backgroundColor: isOpen ? Colors.success : Colors.error },
        dotAnimatedStyle,
      ]} />
      <Text style={[
        styles.statusText,
        { color: isOpen ? Colors.success : Colors.error }
      ]}>
        {isOpen ? 'Aberto' : 'Fechado'}
      </Text>
    </View>
  );
}

function RatingStars({ rating }) {
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.5;

  return (
    <View style={styles.ratingContainer}>
      <View style={styles.stars}>
        {[...Array(5)].map((_, index) => {
          const isFilled = index < fullStars;
          const isHalf = index === fullStars && hasHalfStar;
          
          return (
            <AnimatedStar
              key={index}
              filled={isFilled}
              half={isHalf}
              delay={index * 50}
            />
          );
        })}
      </View>
      <Text style={styles.ratingText}>{rating.toFixed(1)}</Text>
    </View>
  );
}

function AnimatedStar({ filled, half, delay }) {
  const scale = useSharedValue(0);

  useEffect(() => {
    scale.value = withDelay(
      delay,
      withSpring(1, Motion.spring.bouncy)
    );
  }, [delay]);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  return (
    <Animated.View style={animatedStyle}>
      <Ionicons
        name={filled ? 'star' : half ? 'star-half' : 'star-outline'}
        size={14}
        color={Colors.rating}
      />
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.backgroundLight,
    borderRadius: BorderRadius.xl,
    marginBottom: Spacing.lg,
    overflow: 'hidden',
    ...Shadows.large,
  },
  imageContainer: {
    width: '100%',
    height: 180,
    backgroundColor: Colors.backgroundGray,
  },
  image: {
    width: '100%',
    height: '100%',
  },
  discountBadge: {
    position: 'absolute',
    top: Spacing.md,
    left: Spacing.md,
    borderRadius: BorderRadius.md,
    overflow: 'hidden',
    ...Shadows.medium,
  },
  discountGradient: {
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    overflow: 'hidden',
  },
  shimmer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    width: 50,
  },
  discountText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.extrabold,
    color: Colors.textLight,
  },
  favoriteButton: {
    position: 'absolute',
    top: Spacing.md,
    right: Spacing.md,
    width: 40,
    height: 40,
    borderRadius: BorderRadius.md,
    backgroundColor: 'rgba(0,0,0,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    gap: Spacing.sm,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  name: {
    flex: 1,
    fontWeight: FontWeights.bold,
    color: Colors.textPrimary,
    marginRight: Spacing.sm,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.sm,
    gap: 4,
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  statusText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.semibold,
  },
  tags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.xs,
  },
  tag: {
    backgroundColor: Colors.backgroundGray,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.xs,
  },
  tagText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.medium,
    color: Colors.textSecondary,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  metrics: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  stars: {
    flexDirection: 'row',
    gap: 2,
  },
  ratingText: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.textPrimary,
  },
  metric: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metricText: {
    fontSize: FontSizes.xs,
    fontWeight: FontWeights.medium,
    color: Colors.textSecondary,
  },
  metricDivider: {
    width: 1,
    height: 12,
    backgroundColor: Colors.border,
  },
  deliveryFee: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    color: Colors.textSecondary,
  },
  deliveryFeeFree: {
    color: Colors.success,
  },
});
