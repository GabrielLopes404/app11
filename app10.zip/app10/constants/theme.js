export const Colors = {
  primary: '#4F5DFF',
  primaryDark: '#3D48CC',
  primaryLight: '#EEF0FF',
  primaryGlow: 'rgba(79, 93, 255, 0.4)',
  primarySurface: '#4F5DFF',
  primarySurfaceLight: '#6B77FF',
  primarySurfaceDark: '#3D48CC',
  
  twilight: '#9333EA',
  twilightDark: '#7E22CE',
  twilightLight: '#F3E8FF',
  twilightGlow: 'rgba(147, 51, 234, 0.4)',
  
  secondary: '#06B6D4',
  secondaryDark: '#0891B2',
  secondaryLight: '#CFFAFE',
  secondaryGlow: 'rgba(6, 182, 212, 0.3)',
  
  accent: '#00C2A8',
  accentDark: '#00A89A',
  accentLight: '#CCFFF5',
  accentGlow: 'rgba(0, 194, 168, 0.3)',
  
  background: '#FAFBFC',
  backgroundLight: '#FFFFFF',
  backgroundGray: '#F1F5F9',
  backgroundDark: '#0F172A',
  backgroundCard: '#FFFFFF',
  backgroundElevated: '#F8FAFC',
  
  textPrimary: '#0F172A',
  textSecondary: '#64748B',
  textTertiary: '#94A3B8',
  textLight: '#FFFFFF',
  textDark: '#1E293B',
  textMuted: '#CBD5E1',
  
  border: '#E2E8F0',
  borderLight: '#F1F5F9',
  borderDark: '#CBD5E1',
  borderFocus: '#5B4FFF',
  
  success: '#10B981',
  successLight: '#D1FAE5',
  successDark: '#059669',
  error: '#EF4444',
  errorLight: '#FEE2E2',
  errorDark: '#DC2626',
  warning: '#F59E0B',
  warningLight: '#FEF3C7',
  warningDark: '#D97706',
  info: '#3B82F6',
  infoLight: '#DBEAFE',
  infoDark: '#2563EB',
  rating: '#FBBF24',
  
  overlay: 'rgba(15, 23, 42, 0.5)',
  overlayLight: 'rgba(15, 23, 42, 0.2)',
  overlayDark: 'rgba(15, 23, 42, 0.8)',
  overlayGradient: 'linear-gradient(180deg, rgba(15, 23, 42, 0) 0%, rgba(15, 23, 42, 0.8) 100%)',
  
  gradientTwilight: ['#4F5DFF', '#3D48CC'],
  gradientTwilightReverse: ['#3D48CC', '#4F5DFF'],
  gradientPrimary: ['#4F5DFF', '#3D48CC'],
  gradientSunset: ['#00C2A8', '#00A89A'],
  gradientSuccess: ['#10B981', '#059669'],
  gradientPurple: ['#4F5DFF', '#3D48CC'],
  gradientBlue: ['#3B82F6', '#2563EB'],
  gradientAurora: ['#4F5DFF', '#3D48CC'],
  gradientSky: ['#06B6D4', '#0891B2'],
  
  gradientPremiumViolet: ['#4F5DFF', '#3D48CC'],
  gradientPremiumOcean: ['#06B6D4', '#0891B2'],
  gradientPremiumCoral: ['#00C2A8', '#00A89A'],
  gradientPremiumEmerald: ['#10B981', '#059669'],
  gradientPremiumRose: ['#E11D48', '#DC2626'],
  gradientPremiumAmber: ['#00C2A8', '#00A89A'],
  gradientShimmer: ['#FFFFFF', '#F8FAFC'],
  gradientHero: ['#4F5DFF', '#3D48CC'],
  gradientMagic: ['#4F5DFF', '#3D48CC'],
  gradientNeon: ['#10B981', '#059669'],
  
  glass: {
    white: 'rgba(255, 255, 255, 0.85)',
    light: 'rgba(255, 255, 255, 0.7)',
    medium: 'rgba(255, 255, 255, 0.5)',
    dark: 'rgba(15, 23, 42, 0.85)',
    twilight: 'rgba(91, 79, 255, 0.15)',
    ultraLight: 'rgba(255, 255, 255, 0.4)',
    frost: 'rgba(255, 255, 255, 0.6)',
    smoke: 'rgba(0, 0, 0, 0.1)',
  },
  
  shadow: {
    primary: 'rgba(91, 79, 255, 0.25)',
    twilight: 'rgba(147, 51, 234, 0.25)',
    dark: 'rgba(15, 23, 42, 0.15)',
    colored: 'rgba(91, 79, 255, 0.3)',
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
  huge: 40,
  massive: 48,
};

export const BorderRadius = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  round: 999,
};

export const FontSizes = {
  xs: 11,
  sm: 13,
  md: 15,
  lg: 17,
  xl: 20,
  xxl: 24,
  xxxl: 28,
  huge: 34,
  massive: 40,
  displayMD: 36,
  displayLG: 42,
  displayXL: 52,
};

export const FontWeights = {
  light: '300',
  regular: '400',
  medium: '500',
  semibold: '600',
  bold: '700',
  extrabold: '800',
};

export const LineHeights = {
  tight: 1.2,
  normal: 1.5,
  relaxed: 1.75,
  loose: 2,
};

export const Shadows = {
  xs: {
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.04,
    shadowRadius: 2,
    elevation: 1,
  },
  small: {
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  medium: {
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 4,
  },
  large: {
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.12,
    shadowRadius: 16,
    elevation: 8,
  },
  xl: {
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.16,
    shadowRadius: 24,
    elevation: 12,
  },
  xxl: {
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.2,
    shadowRadius: 32,
    elevation: 16,
  },
  colored: {
    shadowColor: '#5B4FFF',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 6,
  },
  twilight: {
    shadowColor: '#9333EA',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 20,
    elevation: 8,
  },
  glow: {
    shadowColor: '#5B4FFF',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 24,
    elevation: 10,
  },
  premiumMulti: {
    shadowColor: '#5B4FFF',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 20,
    elevation: 10,
  },
  premiumSoft: {
    shadowColor: '#94A3B8',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 3,
  },
  premiumFloating: {
    shadowColor: '#0F172A',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.15,
    shadowRadius: 40,
    elevation: 15,
  },
};

export const Animations = {
  instant: 100,
  fast: 200,
  normal: 300,
  slow: 500,
  slower: 700,
  slowest: 1000,
};

export const Motion = {
  easing: {
    easeInOut: 'cubic-bezier(0.4, 0.0, 0.2, 1)',
    easeOut: 'cubic-bezier(0.0, 0.0, 0.2, 1)',
    easeIn: 'cubic-bezier(0.4, 0.0, 1, 1)',
    sharp: 'cubic-bezier(0.4, 0.0, 0.6, 1)',
    spring: 'cubic-bezier(0.175, 0.885, 0.32, 1.275)',
    premium: 'cubic-bezier(0.34, 1.56, 0.64, 1)',
    smooth: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
  },
  duration: {
    instant: 100,
    fast: 200,
    normal: 300,
    slow: 500,
    slower: 700,
    slowest: 1000,
  },
  spring: {
    gentle: { damping: 20, stiffness: 300 },
    bouncy: { damping: 10, stiffness: 200 },
    stiff: { damping: 25, stiffness: 400 },
    smooth: { damping: 30, stiffness: 300 },
    snappy: { damping: 15, stiffness: 250 },
  },
  transition: {
    fade: { duration: 300, easing: 'ease-in-out' },
    slide: { duration: 400, easing: 'ease-out' },
    scale: { duration: 250, easing: 'spring' },
    bounce: { duration: 500, easing: 'spring' },
    shimmer: { duration: 2000, easing: 'linear' },
  },
};

export const Breakpoints = {
  small: 320,
  medium: 375,
  large: 414,
  tablet: 768,
  desktop: 1024,
};

export const Layout = {
  screenPadding: Spacing.lg,
  cardPadding: Spacing.lg,
  headerHeight: 64,
  tabBarHeight: 68,
  maxWidth: 600,
  minTouchTarget: 44,
  iconSize: {
    xs: 16,
    sm: 20,
    md: 24,
    lg: 32,
    xl: 40,
    xxl: 48,
  },
  elevation: {
    flat: 0,
    low: 2,
    medium: 4,
    high: 8,
    highest: 16,
  },
};

export const Typography = {
  displayXL: {
    fontSize: FontSizes.displayXL,
    fontWeight: FontWeights.extrabold,
    lineHeight: LineHeights.tight,
    letterSpacing: -1.5,
  },
  displayLG: {
    fontSize: FontSizes.displayLG,
    fontWeight: FontWeights.extrabold,
    lineHeight: LineHeights.tight,
    letterSpacing: -1,
  },
  displayMD: {
    fontSize: FontSizes.displayMD,
    fontWeight: FontWeights.bold,
    lineHeight: LineHeights.tight,
    letterSpacing: -0.5,
  },
  h1: {
    fontSize: FontSizes.massive,
    fontWeight: FontWeights.extrabold,
    lineHeight: LineHeights.tight,
    letterSpacing: -0.5,
  },
  h2: {
    fontSize: FontSizes.huge,
    fontWeight: FontWeights.bold,
    lineHeight: LineHeights.tight,
    letterSpacing: -0.3,
  },
  h3: {
    fontSize: FontSizes.xxxl,
    fontWeight: FontWeights.bold,
    lineHeight: LineHeights.normal,
  },
  h4: {
    fontSize: FontSizes.xxl,
    fontWeight: FontWeights.semibold,
    lineHeight: LineHeights.normal,
  },
  body: {
    fontSize: FontSizes.md,
    fontWeight: FontWeights.regular,
    lineHeight: LineHeights.relaxed,
  },
  bodyLarge: {
    fontSize: FontSizes.lg,
    fontWeight: FontWeights.regular,
    lineHeight: LineHeights.relaxed,
  },
  caption: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.regular,
    lineHeight: LineHeights.normal,
  },
  label: {
    fontSize: FontSizes.sm,
    fontWeight: FontWeights.semibold,
    lineHeight: LineHeights.normal,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
};

export const Glassmorphism = {
  light: {
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    backdropFilter: 'blur(10px)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  medium: {
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    backdropFilter: 'blur(16px)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  dark: {
    backgroundColor: 'rgba(26, 29, 41, 0.7)',
    backdropFilter: 'blur(10px)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  premium: {
    backgroundColor: 'rgba(255, 255, 255, 0.85)',
    backdropFilter: 'blur(20px)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.4)',
  },
  frost: {
    backgroundColor: 'rgba(255, 255, 255, 0.6)',
    backdropFilter: 'blur(24px)',
    borderWidth: 0.5,
    borderColor: 'rgba(255, 255, 255, 0.25)',
  },
  blur: {
    light: 10,
    medium: 16,
    heavy: 20,
    ultra: 24,
  },
  opacity: {
    subtle: 0.4,
    medium: 0.6,
    strong: 0.85,
  },
};

export const FluidSpacing = (screenWidth) => {
  const baseWidth = 375;
  const scale = screenWidth / baseWidth;
  
  return {
    xs: Math.max(4, Spacing.xs * scale),
    sm: Math.max(6, Spacing.sm * scale),
    md: Math.max(10, Spacing.md * scale),
    lg: Math.max(14, Spacing.lg * scale),
    xl: Math.max(18, Spacing.xl * scale),
    xxl: Math.max(22, Spacing.xxl * scale),
    xxxl: Math.max(28, Spacing.xxxl * scale),
  };
};
